import java.util.Random;

/**
 * 
 * Xogador, será cada axente que xogue o xogo.
 * Este será de varios tipos. (Fixo, Random, Intelixente)
 * Calculará o movemento adecuado e intercambiará os mensaxes co arbitro do xogo.
 * En este caso é o axente Intelixente, que utilizando algoritmos de GameTheory, MachineLearning
 * optará pola decisión mais adecuada.
 * 
 * @author Bruno Nogareda Da Cruz, brunonogareda@gmail.com
 * @version 0.2
 *
 */
@SuppressWarnings("serial")
public class psi29_Intelx extends psi29_Fixed {

	private int miPos;	//Indica la posición del jugador actual de la matriz (0 el de menor id - Filas, 1 el de mayor id - Columnas)
	private int tuPos;	//Indica la posición del jugador contrario de la matriz (0 el de menor id - Filas, 1 el de mayor id - Columnas)
	
	/**
	 * Constructor do axente Intelx, simplemente chama o constructor da clase Fixed e modifica o seu tipo por Intelixente.
	 */
	public psi29_Intelx() {
		super();
		Tipo="Intelixente";
	}
	
	public int xogada() {
		
		//TODO Decidir a xogada mais adecuada
		
		int posTemp=0;
		
		for(int i=0; i<tamMatriz; i++) {
			for(int j=0; j<tamMatriz; j++) {
				if(Matriz[0][i][j]==-1) {
					break;
				}
				else {
					if(Matriz[miPos][i][j]>Matriz[tuPos][i][j]) {
						if(miPos==1) return j;
						else return i;
					}
					
				}
			}
		}
		
		Random rand = new Random();
		return rand.nextInt(tamMatriz);
	}
	
	
	/**
	 * Función que actualizará os parámetros xogados na última ronda
	 * @param xogada1 Fila seleccionada polo xogador de menor id
	 * @param xogada2 Columna seleccionada polo xogador de maior id
	 * @param payoff1 Payoff do xogador de menor id
	 * @param payoff2 Payoff do xogador de maior id
	 */
	public void resultado(int xogada1, int xogada2, int payoff1, int payoff2) {
		Matriz[0][xogada1][xogada2] = payoff1;
		Matriz[1][xogada1][xogada2] = payoff2;
		if(xogada1!=xogada2) {
			Matriz[1][xogada2][xogada1] = payoff1;
			Matriz[0][xogada2][xogada1] = payoff2;
		}
	}
	
	/**
	 * Función para actualizar os parámetros de un novo xogo.
	 * @param numXogadores  Número de xogadores no xogo.
	 * @param tamMatriz Tamaño da matriz no xogo.
	 * @param numRondas Número de rondas en cada partida no xogo actual.
	 * @param numCambMatriz Número de rondas para que cambie a matriz.
	 * @param porCambMatriz Porcentaxe de cambio de matriz.
	 */
	public void inicioXogo(int numXogadores, int tamMatriz, int numRondas, int numCambMatriz, int porCambMatriz) {
		super.inicioXogo(numXogadores, tamMatriz, numRondas, numCambMatriz, porCambMatriz);
		Matriz = new int[2][tamMatriz][tamMatriz];
	}//inicioXogo
	
	/**
	 * Función para informar dos xogadores que intervirán na nova partida
	 * @param idXog1 Id do xogador con menor id (Xogador de filas)
	 * @param idXog2 Id do xogador con maior id (Xogador de columnas)
	 */
	public void inicioPartida(int idXog1, int idXog2) {
		
		//Resetea a matriz memorizada
		for(int i=0; i<tamMatriz; i++) {
			for(int j=0; j<tamMatriz; j++) {
				Matriz[0][i][j] = -1;
				Matriz[1][i][j] = -1;
			}
		}
		
		//Obtenemos nuestra posición en la matriz y la del contrario.
		if(idXog1==Id) {
			miPos=0;
			tuPos=1;
		}
		if(idXog2==Id) {
			miPos=1;
			tuPos=0;
		}
		
	}//inicioPartida
	
	/**
	 * Función para informar a intelixencia artifial do fin da partida.
	 */
	public void finPartida() {
	}//finPartida
	
	
	public void printMatriz() {
		String matriz="";
		for(int i=0; i<tamMatriz; i++) {
			for(int j=0; j<tamMatriz; j++) {
				matriz+="(";
				matriz+=Matriz[0][i][j];
				matriz+=",";
				matriz+=Matriz[1][i][j];
				matriz+=") ";
			}
			matriz+="\n";
		 }
		System.out.println(matriz);
	}
	
	/**
	 * Función para informar a intelixencia artificial do cambio da matriz en un porcentaxe
	 * @param porCamMatriz Porcentaxe de cambio de matriz.
	 */
	public void cambioMatriz(int porCamMatriz) {
	}//cambioMatriz
	
	
	
}
