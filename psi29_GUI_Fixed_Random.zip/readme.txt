Autor: Bruno Nogareda Da Cruz <brunonogareda@gmail.com>
Cuenta: psi29
Descripción:
La clase MainAg se encarga de buscar los jugadores de tipo Player e intercambiar mensajes con estos, además de lanzar la GUI del juego.
El agente Fixed, tiene el código de la lógica de mensajes, y el agente Random hereda de este, por lo tanto, para ejecutar el Random es necesario el Fixed.
En la GUI, por defecto están activado los comentarios cortos (solo informe de partidas), podemos activar los comentarios largos (ralentiza el juego) en la pestaña "Xanela".
En la GUI, al terminar un juego, permanecen las estádisticas de este y solo se borran al lanzar un nuevo juego.